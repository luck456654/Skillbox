window.addEventListener('DOMContentLoaded',function(){
let burgermenu=document.querySelector(".burger").addEventListener(`click`,function(){
	document.querySelector(".burgermenu").classList.toggle('isActive')
	});
	});
	
	